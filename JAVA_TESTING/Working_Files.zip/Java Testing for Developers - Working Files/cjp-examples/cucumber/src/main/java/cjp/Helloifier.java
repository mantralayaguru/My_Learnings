package cjp;

public class Helloifier {

	public String hello() {
		return "Hello, world";
	}

	public String hello(String s) {
		return "Hello, " + s;
	}
}
