import org.junit.Test;

/**
 * This test is just here to show that Java/JUnit and Groovy/Spock can run
 * together in the same project without any special setup.
 */
public class DummyTest {

	@Test
	public void testOne() {
		System.out.println("DummyTest.testOne() was here");
	}
}
