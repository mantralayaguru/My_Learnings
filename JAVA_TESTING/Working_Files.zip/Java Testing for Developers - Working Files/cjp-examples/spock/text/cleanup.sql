drop database javatest;
drop role javatest;
