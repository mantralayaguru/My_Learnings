This directory was moved to ../fbmining to avoid having FindBugs find all
the historical jar files if you say "findbugs .".
