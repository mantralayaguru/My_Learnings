package intro;

/**
 * Your basic, minimal, Hello World type program in Java.
 */
public class HelloWorld {
	public static void main(String[] argv) {
		System.out.println("Hello, World");

	}
}
