package com.scispike.command.simple;

public interface Function {

	int apply(int i);

}
