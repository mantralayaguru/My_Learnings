package com.scispike.proxy;

public class BusinessObjectImplementation extends BusinessObject {

	/* (non-Javadoc)
	 * @see com.scispike.proxy.BusinessObject#sayHi()
	 */
	@Override
	public void sayHi() {
		System.out.println("Hello! Have a nice day!");
	}
}
