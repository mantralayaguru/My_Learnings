package com.scispike.composite;

public interface Expression {

	double getValue();

}
