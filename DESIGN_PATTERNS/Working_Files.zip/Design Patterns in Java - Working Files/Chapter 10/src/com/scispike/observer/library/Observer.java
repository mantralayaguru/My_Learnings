package com.scispike.observer.library;

public interface Observer {
	public void update(Observable o);
}
